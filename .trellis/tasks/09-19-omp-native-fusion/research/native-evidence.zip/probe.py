import base64
import gzip
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path('/work')
fixtures = json.loads((ROOT / 'fixtures.json').read_text())
requests = []
messages = queue.Queue()
request_lock = threading.Lock()
lead_chat_count = 0

def proto_string(data, wanted):
    def varint(offset):
        value = shift = 0
        while True:
            byte = data[offset]
            offset += 1
            value |= (byte & 127) << shift
            if byte < 128:
                return value, offset
            shift += 7
    offset = 0
    while offset < len(data):
        tag, offset = varint(offset)
        field, wire = tag >> 3, tag & 7
        if wire == 0:
            _, offset = varint(offset)
        elif wire == 1:
            offset += 8
        elif wire == 5:
            offset += 4
        elif wire == 2:
            length, offset = varint(offset)
            value = data[offset:offset + length]
            offset += length
            if field == wanted:
                return value.decode()
        else:
            raise ValueError(f'unhandled wire type {wire}')
    return ''

def request_payload(headers, body):
    if headers.get('content-encoding') == 'gzip':
        body = gzip.decompress(body)
    if 'connect+proto' in headers.get('content-type', ''):
        flags = body[0]
        body = body[5:5 + int.from_bytes(body[1:5], 'big')]
        if flags & 1:
            body = gzip.decompress(body)
    return body
for directory in ('home', 'home/.config/devin', 'workspace', 'captures'):
    (ROOT / directory).mkdir(parents=True, exist_ok=True)
(ROOT / 'home/.config/devin/config.json').write_text(json.dumps({
    'auto_update': False,
    'proxy': {'mode': 'off'},
    'read_config_from': {'cursor': False, 'windsurf': False, 'claude': False},
    'agent': {'model': 'fusion-gpt-5-6-sol-xhigh-sidekick-swe-2-high'},
}))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        self.respond(b'{"version":2,"features":[]}', 'application/json')

    def respond(self, body, content_type='application/proto'):
        self.send_response(200)
        self.send_header('content-type', content_type)
        self.send_header('content-length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        global lead_chat_count
        body = self.rfile.read(int(self.headers.get('content-length', '0')))
        with request_lock:
            index = len(requests)
            record = {'index': index, 'path': self.path, 'headers': dict(self.headers), 'bytes': len(body)}
            requests.append(record)
            (ROOT / 'captures' / f'{index:03d}.bin').write_bytes(body)
            (ROOT / 'requests.json').write_text(json.dumps(requests, indent=2))
        print('RPC', index, self.path, len(body), flush=True)
        method = self.path.rsplit('/', 1)[-1]
        if method == 'AssignModel' and 'AssignSidekick' in fixtures:
            payload = request_payload(self.headers, body)
            router = proto_string(payload, 2)
            fusion_context = proto_string(payload, 6)
            fixture = 'AssignSidekick' if fusion_context else 'AssignModel'
            print('ASSIGN_ROUTER', router, 'field6', fusion_context, 'fixture', fixture, flush=True)
            self.respond(base64.b64decode(fixtures[fixture]))
        elif method == 'GetChatMessage' and 'STREAM_HANDOFF' in fixtures:
            uid = proto_string(request_payload(self.headers, body), 21)
            if uid == 'gpt-5-6-sol-xhigh':
                lead_chat_count += 1
            if uid == 'gpt-5-6-sol-xhigh' and lead_chat_count == 1:
                fixture = 'STREAM_HANDOFF'
            elif uid == 'gpt-5-6-sol-xhigh' and lead_chat_count == 3 and 'STREAM_HANDOFF_2' in fixtures:
                fixture = 'STREAM_HANDOFF_2'
            else:
                fixture = 'STREAM_TEXT'
            print('CHAT_UID', uid, 'fixture', fixture, flush=True)
            self.respond(base64.b64decode(fixtures[fixture]), 'application/connect+proto')
        elif method in fixtures:
            self.respond(base64.b64decode(fixtures[method]))
        elif method == 'GetChatMessage':
            trailer = json.dumps({'error': {'code': 'invalid_argument', 'message': 'offline request capture complete'}}).encode()
            frame = bytes([2]) + len(trailer).to_bytes(4, 'big') + trailer
            self.respond(frame, 'application/connect+proto')
        else:
            self.respond(b'')

server = ThreadingHTTPServer(('127.0.0.1', 18080), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print('PROBE_READY network=isolated credentials=synthetic endpoint=loopback', flush=True)
env = dict(os.environ)
env.update({
    'HOME': '/work/home', 'XDG_CONFIG_HOME': '/work/home/.config',
    'XDG_DATA_HOME': '/work/home/.local/share', 'XDG_CACHE_HOME': '/work/home/.cache',
    'WINDSURF_API_KEY': 'offline-probe-session-token',
    'WINDSURF_API_SERVER_URL': 'http://127.0.0.1:18080',
    'RUST_LOG': 'chisel=debug,chisel_api=debug,chisel_agent=debug,chisel_server=debug',
    'NO_COLOR': '1', 'TERM': 'dumb',
})
stderr_file = (ROOT / 'native-stderr.log').open('w')
process = subprocess.Popen(
    ['/opt/native/bin/devin', 'acp', '--model', 'fusion-gpt-5-6-sol-xhigh-sidekick-swe-2-high'],
    cwd='/work/workspace', env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
    stderr=stderr_file, text=True, bufsize=1,
)

def receive():
    with (ROOT / 'acp.jsonl').open('w') as output:
        for line in process.stdout:
            output.write(line)
            output.flush()
            try:
                messages.put(json.loads(line))
            except json.JSONDecodeError:
                print('NON_JSON', line[:200], flush=True)
    messages.put({'probe_eof': True})

threading.Thread(target=receive, daemon=True).start()

def send(message):
    process.stdin.write(json.dumps(message) + '\n')
    process.stdin.flush()

def rpc(identifier, method, params):
    send({'jsonrpc': '2.0', 'id': identifier, 'method': method, 'params': params})
    deadline = time.monotonic() + 40
    while time.monotonic() < deadline:
        try:
            event = messages.get(timeout=max(0.1, deadline - time.monotonic()))
        except queue.Empty:
            break
        if event.get('probe_eof'):
            raise RuntimeError(f'native exited {process.poll()} during {method}')
        if event.get('id') == identifier and ('result' in event or 'error' in event):
            print('ACP_RESULT', method, json.dumps(event)[:1200], flush=True)
            if 'error' in event:
                raise RuntimeError(json.dumps(event['error']))
            return event['result']
        if 'method' in event and 'id' in event:
            if event['method'] == 'session/request_permission':
                send({'jsonrpc': '2.0', 'id': event['id'], 'result': {'outcome': {'outcome': 'cancelled'}}})
            else:
                send({'jsonrpc': '2.0', 'id': event['id'], 'error': {'code': -32601, 'message': 'offline probe'}})
    raise TimeoutError(method)

try:
    rpc(1, 'initialize', {'protocolVersion': 1, 'clientInfo': {'name': 'offline-fusion-probe', 'version': '1'}, 'clientCapabilities': {}})
    session = rpc(2, 'session/new', {'cwd': '/work/workspace', 'mcpServers': []})
    rpc(3, 'session/prompt', {'sessionId': session['sessionId'], 'prompt': [{'type': 'text', 'text': 'test'}]})
    if 'STREAM_HANDOFF_2' in fixtures:
        rpc(4, 'session/prompt', {'sessionId': session['sessionId'], 'prompt': [{'type': 'text', 'text': 'test second native Fusion turn'}]})
except Exception as error:
    print('PROBE_END', type(error).__name__, str(error)[:1600], flush=True)
finally:
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    server.shutdown()
    stderr_file.close()
    print('RPC_SEQUENCE', json.dumps([record['path'] for record in requests]), flush=True)
