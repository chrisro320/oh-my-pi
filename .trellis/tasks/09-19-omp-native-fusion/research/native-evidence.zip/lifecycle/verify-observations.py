import json
from pathlib import Path
root = Path(__file__).parent
results = {}
for case in ('cancel-late', 'failure', 'resume', 'tool-read-execution'):
    routes = json.loads((root / case / 'identity-decoded.json').read_text())
    events = [json.loads(line) for line in (root / case / 'timeline.jsonl').read_text().splitlines()]
    assert not any(e['kind'] == 'barrier_timeout' for e in events), case
    children = [r for r in routes if r.get('model') == 'swe-2-high']
    leads = [r for r in routes if r.get('model') == 'gpt-5-6-sol-xhigh']
    for request in children + leads:
        calls = {c['id'] for m in request['messages'] for c in m['toolCalls']}
        assert all(m['toolCallId'] in calls for m in request['messages'] if m['source'] == 4), case
    if case == 'cancel-late':
        stopped = next(e for e in events if e['kind'] == 'first_prompt_finished')
        late = next(e for e in events if e['kind'] == 'child_response_released_after_cancel')
        assert stopped['result']['stopReason'] == 'cancelled'
        assert stopped['time_ns'] < late['time_ns']
        outcome = next(m for m in leads[-1]['messages'] if m['toolCallId'] == 'lead-read-after-cancel')
        assert 'Canceled by user' in outcome['prompt']
        assert not any('READY (synthetic offline fixture)' in m['prompt'] for m in leads[-1]['messages'])
        assert len(children) == 1
    elif case == 'failure':
        assert len(children) == 1
        messages = leads[-1]['messages']
        result = next(i for i,m in enumerate(messages) if m['toolCallId'] == 'lead-wait-child')
        error = next(i for i,m in enumerate(messages) if m['source'] == 1 and 'SYNTHETIC_CHILD_FAILURE_SENTINEL' in m['prompt'])
        assert result < error
        assert '[Error]' in messages[error]['prompt']
    elif case == 'resume':
        assert any(e['kind'] == 'native_restart' for e in events)
        assert any(e['kind'] == 'resumed_prompt_finished' and e['result']['stopReason'] == 'end_turn' for e in events)
        assert len(children) == 2 and children[0]['cascade'] != children[1]['cascade']
        assert any('Offline protocol probe: reply READY' in m['prompt'] for m in children[1]['messages'])
        assert any(m['source'] == 2 and m['prompt'] == 'READY (synthetic offline fixture)' for m in children[1]['messages'])
        assert any('Second handoff: reply READY TWO' in m['prompt'] for m in children[1]['messages'])
    else:
        opened = next(e for e in events if e['kind'] == 'native_pipe_reader_open' and e.get('stage') == 'execution')
        update = next(e for e in events if e['kind'] == 'lead_response' and e['fixture'] == 'STREAM_INTERRUPT')
        released = next(e for e in events if e['kind'] == 'pipe_release')
        assert opened['time_ns'] < update['time_ns'] < released['time_ns']
        statuses = [e for e in events if e['kind'] == 'acp_in' and e.get('event',{}).get('params',{}).get('update',{}).get('toolCallId') == 'sk::child-read-pipe']
        assert any(e['event']['params']['update'].get('status') == 'in_progress' and e['time_ns'] < update['time_ns'] for e in statuses)
        assert any(e['event']['params']['update'].get('status') == 'completed' and e['time_ns'] > released['time_ns'] for e in statuses)
        assert len(children) == 2 and children[0]['cascade'] == children[1]['cascade']
        messages = children[1]['messages']
        result = next(i for i,m in enumerate(messages) if m['toolCallId'] == 'child-read-pipe')
        update_index = next(i for i,m in enumerate(messages) if '<lead_update>' in m['prompt'])
        assert 'ACTUAL_NATIVE_READ_SENTINEL' in messages[result]['prompt']
        assert result < update_index
    results[case] = 'PASS'
print(json.dumps(results, indent=2))
