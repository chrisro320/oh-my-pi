
import {gunzipSync} from 'node:zlib';
const root='/home/chris/.bun/install/global/node_modules/@oh-my-pi/pi-catalog/src/discovery/';
const p=await import(root+'devin-proto.ts');const {fromBinary}=await import(root+'protobuf.ts');
const base=process.argv[2];const records=JSON.parse(await Bun.file(base+'/requests.json').text());const route=[];
for(const r of records.filter(r=>/\/(AssignModel|GetChatMessage)$/.test(r.path))){
 let b=Buffer.from(await Bun.file(`${base}/captures/${String(r.index).padStart(3,'0')}.bin`).arrayBuffer());const h=Object.fromEntries(Object.entries(r.headers).map(([k,v])=>[k.toLowerCase(),v]));if(h['content-encoding']==='gzip')b=gunzipSync(b);if(h['content-type']?.includes('connect+proto')){const f=b[0];b=b.subarray(5,5+b.readUInt32BE(1));if(f&1)b=gunzipSync(b);}
 const method=r.path.split('/').pop();const q=fromBinary(method==='AssignModel'?p.AssignModelRequestSchema:p.GetChatMessageRequestSchema,b);
 route.push({index:r.index,method,router:q.modelRouterUid,model:q.chatModelUid,cascade:q.cascadeId,assignment:q.modelAssignmentJwt,requestId:q.metadata?.requestId,sessionId:q.metadata?.sessionId,promptId:q.promptId,executionId:q.executionId,trajectoryReference:q.trajectoryReference,unknown:q.$unknown?.map(f=>({field:f.no,wire:f.wireType,data:Buffer.from(f.data).toString('hex')})),messages:q.chatMessagePrompts?.map(m=>({source:m.source,prompt:m.prompt,messageId:m.messageId,outputId:m.outputId,thinkingId:m.thinkingId,toolCallId:m.toolCallId,toolResultIsError:m.toolResultIsError,toolCalls:m.toolCalls.map(t=>({id:t.id,name:t.name,args:t.argumentsJson}))}))});
}
await Bun.write(base+'/identity-decoded.json',JSON.stringify(route,(_key,value)=>typeof value==='bigint'?value.toString():value,2));
console.log(JSON.stringify(route.map(r=>({...r,messages:r.messages?.filter(m=>m.source!==1||/BRIEF|handoff|lead_update|notification|SENTINEL|Second handoff/i.test(m.prompt)).map(m=>({...m,prompt:m.prompt.slice(0,1800)}))})),(_key,value)=>typeof value==='bigint'?value.toString():value,2));
