import base64
import gzip
import json
import os
from pathlib import Path
import queue
import select
import socket
import sys
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path('/work')
fixtures = json.loads((ROOT / 'fixtures.json').read_text())
requests = []
messages = queue.Queue()
request_lock = threading.Lock()
lead_chat_count = 0
child_chat_count = 0
scenario = sys.argv[1]
child_started = threading.Event()
lead_wait_sent = threading.Event()
child_closed = threading.Event()
release_child_response = threading.Event()
child_response_sent = threading.Event()
pipe_opened = threading.Event()
release_pipe = threading.Event()
timeline_lock = threading.Lock()
send_lock = threading.Lock()
def trace(kind, **fields):
    with timeline_lock:
        with (ROOT / 'timeline.jsonl').open('a') as out:
            out.write(json.dumps({'time_ns': time.monotonic_ns(), 'kind': kind, **fields}) + '\n')
    print('TRACE', kind, json.dumps(fields), flush=True)


def proto_string(data, wanted):
    def varint(offset):
        value = shift = 0
        while True:
            byte = data[offset]
            offset += 1
            value |= (byte & 127) << shift
            if byte < 128:
                return value, offset
            shift += 7
    offset = 0
    while offset < len(data):
        tag, offset = varint(offset)
        field, wire = tag >> 3, tag & 7
        if wire == 0:
            _, offset = varint(offset)
        elif wire == 1:
            offset += 8
        elif wire == 5:
            offset += 4
        elif wire == 2:
            length, offset = varint(offset)
            value = data[offset:offset + length]
            offset += length
            if field == wanted:
                return value.decode()
        else:
            raise ValueError(f'unhandled wire type {wire}')
    return ''

def request_payload(headers, body):
    if headers.get('content-encoding') == 'gzip':
        body = gzip.decompress(body)
    if 'connect+proto' in headers.get('content-type', ''):
        flags = body[0]
        body = body[5:5 + int.from_bytes(body[1:5], 'big')]
        if flags & 1:
            body = gzip.decompress(body)
    return body
for directory in ('home', 'home/.config/devin', 'workspace', 'captures'):
    (ROOT / directory).mkdir(parents=True, exist_ok=True)
(ROOT / 'home/.config/devin/config.json').write_text(json.dumps({
    'auto_update': False,
    'proxy': {'mode': 'off'},
    'read_config_from': {'cursor': False, 'windsurf': False, 'claude': False},
    'agent': {'model': 'fusion-gpt-5-6-sol-xhigh-sidekick-swe-2-high'},
}))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        self.respond(b'{"version":2,"features":[]}', 'application/json')

    def respond(self, body, content_type='application/proto'):
        self.send_response(200)
        self.send_header('content-type', content_type)
        self.send_header('content-length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        global lead_chat_count, child_chat_count
        body = self.rfile.read(int(self.headers.get('content-length', '0')))
        with request_lock:
            index = len(requests)
            record = {'index': index, 'path': self.path, 'headers': dict(self.headers), 'bytes': len(body)}
            requests.append(record)
            (ROOT / 'captures' / f'{index:03d}.bin').write_bytes(body)
            (ROOT / 'requests.json').write_text(json.dumps(requests, indent=2))
        print('RPC', index, self.path, len(body), flush=True)
        trace('request', index=index, method=self.path.rsplit('/', 1)[-1])
        method = self.path.rsplit('/', 1)[-1]
        if method == 'AssignModel' and 'AssignSidekick' in fixtures:
            payload = request_payload(self.headers, body)
            router = proto_string(payload, 2)
            fusion_context = proto_string(payload, 6)
            fixture = 'AssignSidekick' if fusion_context else 'AssignModel'
            print('ASSIGN_ROUTER', router, 'field6', fusion_context, 'fixture', fixture, flush=True)
            self.respond(base64.b64decode(fixtures[fixture]))
        elif method == 'GetChatMessage':
            uid = proto_string(request_payload(self.headers, body), 21)
            if uid == 'gpt-5-6-sol-xhigh':
                lead_chat_count += 1
                count = lead_chat_count
                fixture = 'STREAM_TEXT'
                if count == 1:
                    fixture = 'STREAM_BLOCK_HANDOFF' if scenario == 'resume' else 'STREAM_HANDOFF'
                elif scenario == 'resume' and count == 3:
                    fixture = 'STREAM_HANDOFF_2'
                elif (scenario in ('cancel', 'failure') and count == 2) or (scenario == 'cancel' and count == 3):
                    fixture = 'STREAM_WAIT_AFTER_CANCEL' if count == 3 else 'STREAM_WAIT'
                elif scenario == 'tool' and count == 2:
                    if not pipe_opened.wait(20):
                        trace('barrier_timeout', barrier='pipe_opened')
                    fixture = 'STREAM_INTERRUPT'
                elif scenario == 'tool' and count == 3:
                    fixture = 'STREAM_WAIT'
                    release_pipe.set()
                trace('lead_response', count=count, fixture=fixture)
                self.respond(base64.b64decode(fixtures[fixture]), 'application/connect+proto')
                if count == 2:
                    lead_wait_sent.set()
            elif uid == 'swe-2-high':
                child_chat_count += 1
                count = child_chat_count
                child_started.set()
                trace('child_request', index=index, count=count)
                if scenario == 'cancel':
                    self.send_response(200)
                    self.send_header('content-type', 'application/connect+proto')
                    response_bytes = base64.b64decode(fixtures['STREAM_TEXT'])
                    self.send_header('content-length', str(len(response_bytes)))
                    self.end_headers()
                    self.wfile.flush()
                    deadline = time.monotonic() + 20
                    while time.monotonic() < deadline:
                        if release_child_response.is_set():
                            self.wfile.write(response_bytes)
                            self.wfile.flush()
                            trace('child_response_released_after_cancel', index=index)
                            child_response_sent.set()
                            return
                        if select.select([self.connection], [], [], .1)[0]:
                            if self.connection.recv(1, socket.MSG_PEEK) == b'':
                                trace('child_transport_closed', index=index)
                                child_closed.set()
                                return
                    trace('barrier_timeout', barrier='child_transport_closed')
                elif scenario == 'failure':
                    trailer = json.dumps({'error': {'code': 'invalid_argument', 'message': 'SYNTHETIC_CHILD_FAILURE_SENTINEL'}}).encode()
                    self.respond(bytes([2]) + len(trailer).to_bytes(4, 'big') + trailer, 'application/connect+proto')
                else:
                    fixture = 'STREAM_READ' if scenario == 'tool' and count == 1 else 'STREAM_TEXT'
                    self.respond(base64.b64decode(fixtures[fixture]), 'application/connect+proto')
            else:
                self.respond(base64.b64decode(fixtures['STREAM_TEXT']), 'application/connect+proto')
        elif method in fixtures:
            self.respond(base64.b64decode(fixtures[method]))
        else:
            self.respond(b'')

server = ThreadingHTTPServer(('127.0.0.1', 18080), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print('PROBE_READY network=isolated credentials=synthetic endpoint=loopback', flush=True)
env = dict(os.environ)
env.update({
    'HOME': '/work/home', 'XDG_CONFIG_HOME': '/work/home/.config',
    'XDG_DATA_HOME': '/work/home/.local/share', 'XDG_CACHE_HOME': '/work/home/.cache',
    'WINDSURF_API_KEY': 'offline-probe-session-token',
    'WINDSURF_API_SERVER_URL': 'http://127.0.0.1:18080',
    'RUST_LOG': 'chisel=debug,chisel_api=debug,chisel_agent=debug,chisel_server=debug',
    'NO_COLOR': '1', 'TERM': 'dumb',
})
stderr_file = (ROOT / 'native-stderr.log').open('w')
process = subprocess.Popen(
    ['/opt/native/bin/devin', 'acp', '--model', 'fusion-gpt-5-6-sol-xhigh-sidekick-swe-2-high'],
    cwd='/work/workspace', env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
    stderr=stderr_file, text=True, bufsize=1,
)

def receive():
    with (ROOT / 'acp.jsonl').open('a') as output:
        for line in process.stdout:
            output.write(line)
            output.flush()
            try:
                event = json.loads(line)
                trace('acp_in', event=event)
                messages.put(event)
            except json.JSONDecodeError:
                print('NON_JSON', line[:200], flush=True)
    messages.put({'probe_eof': True})

receiver = threading.Thread(target=receive, daemon=True)
receiver.start()

def send(message):
    trace('acp_out', event=message)
    with send_lock:
        process.stdin.write(json.dumps(message) + '\n')
        process.stdin.flush()

def rpc(identifier, method, params):
    send({'jsonrpc': '2.0', 'id': identifier, 'method': method, 'params': params})
    deadline = time.monotonic() + 40
    while time.monotonic() < deadline:
        try:
            event = messages.get(timeout=max(0.1, deadline - time.monotonic()))
        except queue.Empty:
            break
        if event.get('probe_eof'):
            raise RuntimeError(f'native exited {process.poll()} during {method}')
        if event.get('id') == identifier and ('result' in event or 'error' in event):
            print('ACP_RESULT', method, json.dumps(event)[:1200], flush=True)
            if 'error' in event:
                raise RuntimeError(json.dumps(event['error']))
            return event['result']
        if 'method' in event and 'id' in event:
            if event['method'] == 'session/request_permission':
                send({'jsonrpc': '2.0', 'id': event['id'], 'result': {'outcome': {'outcome': 'cancelled'}}})
            else:
                send({'jsonrpc': '2.0', 'id': event['id'], 'error': {'code': -32601, 'message': 'offline probe'}})
    raise TimeoutError(method)

try:
    rpc(1, 'initialize', {'protocolVersion': 1, 'clientInfo': {'name': 'offline-fusion-probe', 'version': '1'}, 'clientCapabilities': {}})
    session = rpc(2, 'session/new', {'cwd': '/work/workspace', 'mcpServers': []})
    def cancel_when_child_waits():
        if not child_started.wait(20) or not lead_wait_sent.wait(20):
            trace('barrier_timeout', barrier='cancel_prerequisites')
            return
        time.sleep(.2)
        send({'jsonrpc': '2.0', 'method': 'session/cancel', 'params': {'sessionId': session['sessionId']}})
    def pipe_writer():
        pipe = ROOT / 'workspace/probe.pipe'
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            try:
                fd = os.open(pipe, os.O_WRONLY | os.O_NONBLOCK)
                break
            except OSError:
                time.sleep(.01)
        else:
            trace('barrier_timeout', barrier='native_pipe_reader')
            return
        trace('native_pipe_reader_open')
        pipe_opened.set()
        if release_pipe.wait(20):
            trace('pipe_release')
            try:
                os.write(fd, b'ACTUAL_NATIVE_READ_SENTINEL\n')
            except BrokenPipeError:
                trace('pipe_reader_cancelled')
        else:
            trace('barrier_timeout', barrier='pipe_release')
        os.close(fd)
    if scenario == 'cancel':
        threading.Thread(target=cancel_when_child_waits, daemon=True).start()
    if scenario == 'tool':
        os.mkfifo(ROOT / 'workspace/probe.pipe')
        threading.Thread(target=pipe_writer, daemon=True).start()
    first = rpc(3, 'session/prompt', {'sessionId': session['sessionId'], 'prompt': [{'type': 'text', 'text': 'test'}]})
    trace('first_prompt_finished', result=first)
    if scenario == 'cancel':
        trace('cancel_observation', child_transport_closed=child_closed.wait(1))
        release_child_response.set()
        if not child_response_sent.wait(3):
            raise RuntimeError('late response not delivered')
        second = rpc(7, 'session/prompt', {'sessionId': session['sessionId'], 'prompt': [{'type': 'text', 'text': 'Collect the existing sidekick result after cancelling the prior foreground wait.'}]})
        trace('post_cancel_prompt_finished', result=second)
    if scenario == 'resume':
        # Wait for the first child completion by requesting an explicit wait before restart.
        process.terminate()
        process.wait(timeout=5)
        receiver.join(timeout=5)
        while not messages.empty():
            messages.get_nowait()
        trace('native_restart', session=session['sessionId'])
        process = subprocess.Popen(
            ['/opt/native/bin/devin', 'acp', '--model', 'fusion-gpt-5-6-sol-xhigh-sidekick-swe-2-high'],
            cwd='/work/workspace', env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=stderr_file, text=True, bufsize=1)
        receiver = threading.Thread(target=receive, daemon=True)
        receiver.start()
        rpc(4, 'initialize', {'protocolVersion': 1, 'clientInfo': {'name': 'offline-fusion-probe', 'version': '1'}, 'clientCapabilities': {}})
        rpc(5, 'session/load', {'sessionId': session['sessionId'], 'cwd': '/work/workspace', 'mcpServers': []})
        second = rpc(6, 'session/prompt', {'sessionId': session['sessionId'], 'prompt': [{'type': 'text', 'text': 'test second native Fusion turn'}]})
        trace('resumed_prompt_finished', result=second)

except Exception as error:
    print('PROBE_END', type(error).__name__, str(error)[:1600], flush=True)
    raise
finally:
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    server.shutdown()
    stderr_file.close()
    print('RPC_SEQUENCE', json.dumps([record['path'] for record in requests]), flush=True)
